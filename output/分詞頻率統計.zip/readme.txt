請用 Excel 開啟 tsv 檔案。

檔案內容：
article_original.tsv            文章原文分詞頻率統計（中文）
article_trans.tsv               文章譯文分詞頻率統計（英文）
court_original_Chinese.tsv      法庭原文中文分詞頻率統計
court_original_English.tsv      法庭原文英文分詞頻率統計
court_trans_Chinese.tsv         法庭譯文中文分詞頻率統計
court_trans_English.tsv         法庭譯文英文分詞頻率統計

英文統計包含實虛詞欄位，C 表實詞，F 表虛詞
